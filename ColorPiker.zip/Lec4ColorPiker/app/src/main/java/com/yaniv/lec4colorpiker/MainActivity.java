package com.yaniv.lec4colorpiker;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    SeekBar redSeekBar,blueSeekBar,greenSeekBar,alphaSeekBar;
    TextView tvRed,tvGreen,tvBlue,tvAlpha,hexValue,palette1,colorWindowDisplay;
    // model object ->
    private ColorPicker colorPicker = new ColorPicker();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        redSeekBar =  findViewById(R.id.sbRed);
        blueSeekBar = findViewById(R.id.sbBlue);
        greenSeekBar =  findViewById(R.id.sbGreen);
        alphaSeekBar = findViewById(R.id.sbAlfa);
        hexValue = findViewById(R.id.hexValue);
        tvRed =  findViewById(R.id.tvRed);
        tvGreen =  findViewById(R.id.tvGreen);
        tvBlue =  findViewById(R.id.tvBlue);
        tvAlpha = findViewById(R.id.tvAlfa);
        palette1 = findViewById(R.id.palet1);
        colorWindowDisplay = findViewById(R.id.colorWindowDisplay);
        setSeekBars(); //todo: method listener combine all seekBars.
    }

    // method listener combine all seekBars.
    public void setSeekBars()
    {
        setRedSeekBar();
        setBlueSeekBar();
        setGreenSeekBar();
        setAlphaSeekBar();
    }

    // Red seekBar listener ->
    public void setRedSeekBar()
    {
        redSeekBar.setOnSeekBarChangeListener((new MyOnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tvRed.setText(String.valueOf(i));
                rgbToHexConverter(i,"redSeekBar");
            }
        }));
    }

    // Blue seekBar listener ->
    public void setBlueSeekBar()
    {
        blueSeekBar.setOnSeekBarChangeListener((new MyOnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tvBlue.setText(String.valueOf(i));
                rgbToHexConverter(i,"blueSeekBar");
            }
        }));
    }

    // Green seekBar listener ->
    public void setGreenSeekBar()
    {
        greenSeekBar.setOnSeekBarChangeListener((new MyOnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tvGreen.setText(String.valueOf(i));
                rgbToHexConverter(i,"greenSeekBar");
            }
        }));
    }

    // Green seekBar listener ->
    public void setAlphaSeekBar()
    {
        alphaSeekBar.setOnSeekBarChangeListener((new MyOnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tvAlpha.setText(String.valueOf(i));
                colorPicker.alphaValue(i,colorWindowDisplay,hexValue);
            }
        }));
    }

    // Integer to Hex converter ->
    public void rgbToHexConverter(Integer colorValue, String seekBarID)
    {
        colorPicker.rgbToHex(colorValue,seekBarID,hexValue,colorWindowDisplay);
    }

    @SuppressLint({"ResourceType", "SetTextI18n"})
    // Palette picker method ->
    public void defaultPaletteColors(View view)
    {
        colorPicker.colorPalette(view,colorWindowDisplay,hexValue);
        setAlphaSeekBar(); // for adding the support to change Alpha chanel value to current palette.
    }

}