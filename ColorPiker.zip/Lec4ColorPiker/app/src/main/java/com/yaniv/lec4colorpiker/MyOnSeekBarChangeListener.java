package com.yaniv.lec4colorpiker;

import android.widget.SeekBar;

abstract class MyOnSeekBarChangeListener implements SeekBar.OnSeekBarChangeListener {
    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
