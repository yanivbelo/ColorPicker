package com.yaniv.lec4colorpiker;

import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.TextView;

public class ColorPicker {

    private String tempRedValue = "00";
    private String tempGreenValue = "00";
    private String tempBlueValue = "00";
    private String resultColor;


    //todo: RGB To HEX ->
    public void rgbToHex(Integer colorValue, String seekBarID, TextView hexValue,TextView colorWindowDisplay)
    {
        /**
         * This is for making a 'stroke' border to the preview color display window.
         * Because the main window is created from drawable xml , was needed first to get the
         * background - > than cast it to GradientDrawable object for than to modify the 'Stroke'
         * value (for getting the nice border surrounding the window).
         */
        GradientDrawable gradientDrawable = (GradientDrawable) colorWindowDisplay.getBackground();
        gradientDrawable.setStroke(4, ColorStateList.valueOf(Color.parseColor("#d2d2d2")));

        switch (seekBarID)
        {
            case "redSeekBar":
                if (colorValue < 16) {
                    tempRedValue = "0" + Integer.toHexString(colorValue);
                } else {
                    tempRedValue = Integer.toHexString(colorValue);
                }
                break;
            case "blueSeekBar":
                if (colorValue == null) {
                    tempBlueValue = "00";
                } else if (colorValue < 16) {
                    tempBlueValue = "0" + Integer.toHexString(colorValue);
                } else {
                    tempBlueValue = Integer.toHexString(colorValue);
                }
                break;
            case "greenSeekBar":
                if (colorValue == null) {
                    tempGreenValue = "00";
                } else if (colorValue < 16) {
                    tempGreenValue = "0" + Integer.toHexString(colorValue);
                } else {
                    tempGreenValue = Integer.toHexString(colorValue);
                }
                break;
        }

        hexValue.setText(("#" + tempRedValue + tempGreenValue + tempBlueValue).toUpperCase());
        //todo: result color after playing with all seekBars together ->
        resultColor = "#" + tempRedValue + tempGreenValue + tempBlueValue;
        //todo: setting the result color to color preview window ->
        colorWindowDisplay.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(resultColor)));
    }


    @SuppressLint({"ResourceType", "SetTextI18n"})
    public void colorPalette(View view, TextView colorWindowDisplay,TextView hexValue)
    {
        /**
         * This is for making a 'stroke' border to the preview color display window.
         * Because the main window is created from drawable xml , was needed first to get the
         * background - > than cast it to GradientDrawable object for than to modify the 'Stroke'
         * value (for getting the nice border surrounding the window).
         */
        GradientDrawable gradientDrawable = (GradientDrawable) colorWindowDisplay.getBackground();
        gradientDrawable.setStroke(4,ColorStateList.valueOf(Color.parseColor("#d2d2d2")));

        switch (view.getId())
        {
            case R.id.palet1:
                hexValue.setText("#f44235".toUpperCase());
                colorWindowDisplay.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#f44235")));
                resultColor = "#f44235";
                break;
            case R.id.palet2:
                hexValue.setText("#e91c63".toUpperCase());
                colorWindowDisplay.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#e91c63")));
                resultColor = "#e91c63";
                break;
            case R.id.palet3:
                hexValue.setText("#9c27b0".toUpperCase());
                colorWindowDisplay.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#9c27b0")));
                resultColor = "#9c27b0";
                break;
            case R.id.palet4:
                hexValue.setText("#4050b5".toUpperCase());
                colorWindowDisplay.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#4050b5")));
                resultColor = "#4050b5";
                break;
            case R.id.palet5:
                hexValue.setText("#ff9800".toUpperCase());
                colorWindowDisplay.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#ff9800")));
                resultColor = "#ff9800";
                break;
            case R.id.palet6:
                hexValue.setText("#cddc38".toUpperCase());
                colorWindowDisplay.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#cddc38")));
                resultColor = "#cddc38";
                break;
            case R.id.palet7:
                hexValue.setText("#00bcd4".toUpperCase());
                colorWindowDisplay.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#00bcd4")));
                resultColor = "#00bcd4";
                break;

        }
    }


    @SuppressLint("SetTextI18n")
    public void alphaValue(int alphaValue,TextView colorWindowDisplay,TextView hexValue)
    {
        StringBuilder tempStringBuilder = new StringBuilder();
        tempStringBuilder.append(resultColor);

        //todo: Alpha channel algorithm ->
        int val = (alphaValue * 255) / 100;
        String alphaVal = Integer.toHexString(val);

        // validate if value is one char ->
        if (alphaVal.length() == 1)
        {
            alphaVal = "0"+ alphaVal;
        }

        // as long as value not 0 ->
        if (alphaValue != 0)
        {
            tempStringBuilder.insert(1,alphaVal);
            hexValue.setText(tempStringBuilder.toString().toUpperCase());
            colorWindowDisplay.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(tempStringBuilder.toString())));
        }

        // if value is 0 - >
        else
        {
            tempStringBuilder.insert(1,alphaVal);
            hexValue.setText(resultColor.toUpperCase());
            colorWindowDisplay.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(tempStringBuilder.toString())));
        }
    }

}
